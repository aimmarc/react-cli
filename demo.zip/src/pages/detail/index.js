import React from "react";

const Detail: React.FC = () => {
  return <div>456</div>;
};

export default Detail;
