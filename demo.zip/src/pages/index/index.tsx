import React, { useCallback, useMemo, useState } from "react";
import { Button } from "antd";
import { useRequest } from "@umijs/hooks";
import Child from "./components/Child";

const Index: React.FC = (props) => {
  const [val1, setVal1] = useState("");
  const [val2, setVal2] = useState("");
  const [val3, setVal3] = useState("");
  const [name, setName] = useState("");

  const handleChange1 = useCallback((e: any) => {
    setVal1(e.target.value)
  }, []);

  const handleChange2 = useCallback((e: any) => {
    setVal2(e.target.value)
  }, [])

  const handleChange3 = useCallback((e: any) => {
    setVal3(e.target.value)
  }, [])

  return (
    <div>
      <Child name={name} value={val1} onChange={handleChange1} />
      <Child value={val2} onChange={handleChange2} />
      <Child value={val3} onChange={handleChange3} />
      <Button onClick={() => setName(Math.random() + '')}>呵呵</Button>
    </div>
  );
};

export default Index;
