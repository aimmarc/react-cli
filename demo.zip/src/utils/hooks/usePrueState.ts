import React, { useState, useRef } from "react"

const usePureState = (state, callback) => {
  
}