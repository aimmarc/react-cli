/**
 * strage
 */
const STORAGE_TOKEN: string = "STORAGE_TOKEN";
const STORAGE_USER_INFO: string = "STORAGE_USER_INFO";

export {
  STORAGE_TOKEN,
  STORAGE_USER_INFO,
}