const theme = {
  "@primary-color": "#1DA57A",
};

module.exports = theme;
